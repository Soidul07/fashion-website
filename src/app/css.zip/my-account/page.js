"use client"
import React from 'react';
import { Layouts } from '../Component'
import { FaRegHeart } from "react-icons/fa";
import { FaAngleRight } from "react-icons/fa6";
import { IoCubeOutline } from "react-icons/io5";
import { MdOutlineNotificationAdd } from "react-icons/md";
import { IoPersonCircleOutline } from "react-icons/io5";
import { PiAddressBook } from "react-icons/pi";
import { TbLocationCancel } from "react-icons/tb";
import { TbCalendarCancel } from "react-icons/tb";
import { MdOutlinePrivacyTip } from "react-icons/md";
import { TbTruckReturn } from "react-icons/tb";
import { MdOutlineLocalShipping } from "react-icons/md";
import { TbAirConditioningDisabled } from "react-icons/tb";
import { GrBusinessService } from "react-icons/gr";
import { FaQuinscape } from "react-icons/fa";
import { MdFreeCancellation } from "react-icons/md";
import { MdOutlineFreeCancellation } from "react-icons/md";
import { MdOutlinePolicy } from "react-icons/md";
import { HiOutlineReceiptRefund } from "react-icons/hi";
import { RiRefund2Fill } from "react-icons/ri";
import { TbAirConditioning } from "react-icons/tb";
import { GrServicePlay } from "react-icons/gr";
import { GrServices } from "react-icons/gr";

import Link from 'next/link';

export default function page() {

    return (
        <Layouts>
            <div className='wishlist_panel'>
                <div className='container'>
                    <div className='row'>
                        <div className='cart_panel_top'>
                            <div>
                                <h3>Hey! Fly Customer</h3>
                                <p>Explore</p>
                            </div>
                        </div>
                        <div className='cart_panel_bottom'>
                            <div className='start_shoping'>
                                <div className='start_shoping_icon'>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M217.9 105.9L340.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L217.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1L32 320c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM352 416l64 0c17.7 0 32-14.3 32-32l0-256c0-17.7-14.3-32-32-32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0c53 0 96 43 96 96l0 256c0 53-43 96-96 96l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32z"/></svg>
                                    <span>Create your account and enjoy your shopping.</span>
                                </div>
                                <div className='start_shoping_btns'>
                                    <ul>
                                        <li>
                                            <Link href="/products">Create Account</Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className='account_link account_border'>
                                <ul>
                                    <li>
                                        <Link href="/my-order">
                                            <IoCubeOutline />
                                            <span>Orders</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/">
                                            <FaRegHeart />
                                            <span>Wishlist</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                            <div className='account_setting account_border'>
                                <h2>Notification</h2>
                                <ul>
                                    <li>
                                        <Link href="/notification">
                                            <div>
                                                <MdOutlineNotificationAdd />
                                                <span>Tap for latest notification</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                            <div className='account_setting account_border'>
                                <h2>Account Settings</h2>
                                <ul>
                                    <li>
                                        <Link href="/">
                                            <div>
                                                <IoPersonCircleOutline />
                                                <span>Edit Profile</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/">
                                            <div>
                                                <PiAddressBook />
                                                <span>Saved Addresses</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                            <div className='account_setting account_border'>
                                <h2>Feedback & Information</h2>
                                <ul>
                                    <li>
                                        <Link href="/cancellation-policy">
                                            <div>
                                                <MdOutlinePolicy />
                                                <span>Cancellation Policy</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/order-cancelled">
                                            <div>
                                                <MdOutlineFreeCancellation  />
                                                <span>Order Cancelled</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/privacy-policy">
                                            <div>
                                                <MdOutlinePrivacyTip />
                                                <span>Privacy Policy</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/return-and-refund-policy">
                                            <div>
                                                <RiRefund2Fill  />
                                                <span>Return & Refund Policy</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/shipping-policy">
                                            <div>
                                                <MdOutlineLocalShipping />
                                                <span>Shipping Policy</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/terms-and-conditions">
                                            <div>
                                                <GrServicePlay  />
                                                <span>Terms & Conditions</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/terms-of-service">
                                            <div>
                                                <GrServices  />
                                                <span>Terms Of Service</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="/faq">
                                            <div>
                                                <FaQuinscape />
                                                <span>FAQs</span>
                                            </div>
                                            <div className='angle_svg'>
                                                <FaAngleRight />
                                            </div>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                            <div className='account_setting'>
                                <button>Log Out</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Layouts>
    )
}